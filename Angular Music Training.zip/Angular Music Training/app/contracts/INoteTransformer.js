System.register([], function(exports_1) {
    "use strict";
    return {
        setters:[],
        execute: function() {
        }
    }
});
//# sourceMappingURL=INoteTransformer.js.map