System.register([], function(exports_1) {
    "use strict";
    return {
        setters:[],
        execute: function() {
        }
    }
});
//# sourceMappingURL=IPianoKey.js.map